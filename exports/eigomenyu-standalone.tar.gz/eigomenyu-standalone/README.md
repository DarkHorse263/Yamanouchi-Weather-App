# Eigomenyu

Standalone English-menu app for Japan.

## Setup in a new Replit

1. Create a new Repl (Node template, blank, or import-from-zip).
2. Drop the contents of this folder into the Repl's root.
3. In the Shell, run:
   ```
   npm install
   npm run dev
   ```
4. Vite will start on the `PORT` provided by Replit (or 5173 locally).

## Scripts

- `npm run dev` — start the dev server
- `npm run build` — production build into `dist/`
- `npm run serve` — preview the production build
- `npm run typecheck` — TypeScript check
