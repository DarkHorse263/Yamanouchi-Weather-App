import Foundation

struct DailyReport: Codable, Identifiable {
    let id: UUID
    let resort_id: UUID
    let report_date: String
    let temp_now_c: Double?
    let wind_now_ms: Double?
    let gust_now_ms: Double?
    let snow_24h_cm: Int?
    let lift_wind_risk: String
    let headline: String
}
