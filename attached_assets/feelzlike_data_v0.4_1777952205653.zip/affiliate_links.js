/**
 * FeelZlike — Affiliate deep-link builder
 * ----------------------------------------
 * Single source of truth for all booking site deep-links.
 * When you get your affiliate IDs, fill in the AFFILIATE_IDS object below
 * and EVERY link across the app updates automatically.
 *
 * No code changes required elsewhere — just import buildBookingLinks(stay).
 */

// ============================================================
// 1. AFFILIATE IDS — replace null with your IDs as they arrive
// ============================================================
const AFFILIATE_IDS = {
  booking_com:     null,  // e.g. 'aid=1234567'      — apply: https://www.booking.com/affiliate-program/v2/
  agoda:           null,  // e.g. 'cid=1234567'      — apply: https://partners.agoda.com/
  airbnb:          null,  // associate token         — apply: https://www.airbnb.com/associates
  expedia:         null,  // e.g. 'TPID=1' + 'CAMREF=' — apply: https://www.expediagroup.com/affiliate
  hotels_com:      null,  // EAN affiliate id        — same Expedia partner program
  trip_com:        null,  // SID                     — apply: https://us.trip.com/partners/
  rakuten_travel:  null,  // f_no=                   — apply: https://affiliate.rakuten.co.jp/
  jalan:           null,  // (usually requires JP business entity)
  tripadvisor:     null,  // partner id              — apply: https://www.tripadvisor.com/Affiliates
};

// ============================================================
// 2. URL BUILDERS PER PROVIDER
// ============================================================
const BUILDERS = {
  booking_com: (stay) => {
    const q = encodeURIComponent(`${stay.name} ${stay.town}`);
    const aff = AFFILIATE_IDS.booking_com ? `&${AFFILIATE_IDS.booking_com}` : '';
    return `https://www.booking.com/searchresults.html?ss=${q}${aff}`;
  },
  agoda: (stay) => {
    const q = encodeURIComponent(`${stay.name} ${stay.town}`);
    const aff = AFFILIATE_IDS.agoda ? `&${AFFILIATE_IDS.agoda}` : '';
    return `https://www.agoda.com/search?q=${q}${aff}`;
  },
  airbnb: (stay) => {
    const q = encodeURIComponent(`${stay.town} ${stay.country === 'JP' ? 'Nagano' : 'NSW'}`);
    return `https://www.airbnb.com/s/${q}/homes`;
  },
  expedia: (stay) => {
    const q = encodeURIComponent(stay.town);
    const aff = AFFILIATE_IDS.expedia ? `&${AFFILIATE_IDS.expedia}` : '';
    return `https://www.expedia.com/Hotel-Search?destination=${q}${aff}`;
  },
  hotels_com: (stay) => {
    const q = encodeURIComponent(stay.town);
    return `https://www.hotels.com/Hotel-Search?destination=${q}`;
  },
  trip_com: (stay) => {
    const q = encodeURIComponent(`${stay.name} ${stay.town}`);
    return `https://www.trip.com/hotels/list?city=${q}`;
  },
  rakuten_travel: (stay) => {
    if (stay.country !== 'JP') return null;
    const q = encodeURIComponent(stay.name_local || stay.name);
    return `https://travel.rakuten.co.jp/dsearch/?f_keyword=${q}`;
  },
  jalan: (stay) => {
    if (stay.country !== 'JP') return null;
    const q = encodeURIComponent(stay.name_local || stay.name);
    return `https://www.jalan.net/uw/uwp3000/uww3001.do?keyword=${q}`;
  },
  official: (stay) => stay.website || null,
};

// Which providers serve which markets (so we don't show Jalan for Aussie towns)
const MARKET_PROVIDERS = {
  AU: ['booking_com', 'agoda', 'airbnb', 'expedia', 'hotels_com', 'trip_com', 'official'],
  JP: ['booking_com', 'agoda', 'airbnb', 'expedia', 'rakuten_travel', 'jalan', 'trip_com', 'official'],
};

// ============================================================
// 3. PUBLIC API
// ============================================================
function buildBookingLinks(stay) {
  const providers = MARKET_PROVIDERS[stay.country] || MARKET_PROVIDERS.AU;
  const links = {};
  for (const provider of providers) {
    const url = BUILDERS[provider](stay);
    if (url) links[provider] = url;
  }
  return links;
}

function hasAffiliateId(provider) {
  return Boolean(AFFILIATE_IDS[provider]);
}

function affiliateStatus() {
  return Object.fromEntries(
    Object.entries(AFFILIATE_IDS).map(([k, v]) => [k, v ? 'active' : 'pending'])
  );
}

module.exports = { buildBookingLinks, hasAffiliateId, affiliateStatus, AFFILIATE_IDS };
